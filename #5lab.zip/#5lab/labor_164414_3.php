<?
    $nr_indeksu='164414'
    $nrGrupy='3'

    echo'Jakub Oleksiak'.$164414.'grupa'.$nrGrupy.'<br /><br />';

    echo'Zastosowanie metody include() <br />';

    echo"To jest $color $fruit <br />";
    include 'php/vars.php';
    echo"To jest $color $fruit <br />";

    echo'Zastosowanie metody require_once() <br />';
    $s = require_once('php/text.php');
    echo "\n" . $s;
    $s = require_once('text.php');
    echo "\n" . $s;

    echo'Zasosowanie metody if, else, elseif <br />';
    if($a > $b) {
        echo"a jest wieksze od b";
    } elseif ($a == $b) {
        echo"a jest rowne b";
    } else {
        echo"a jest mniejsze od b";
    }

    echo'Zasosowanie metody switch <br />';

    echo'Zasosowanie metody while() <br />';
    while($i <= 10) {
        echo $i++;
    }

    echo'Zasosowanie metody for() <br />';
    for($j = 1; $j <= 10; j++) {
        echo $j;
    }

    echo'Zasosowanie zmiennej $_GET <br />';
    echo 'Hello ' . htmlspecialchars($_GET["name"]) . '!';

    echo'Zasosowanie zmiennej $_POST <br />';
    echo 'Hello ' . htmlspecialchars($_POST["name"]) . '!';

    echo'Zasosowanie zmiennej $_SESSION <br />';
    // session_start();
    // $_SESSION["newsession"]=$value;
    // echo $_SESSION["newsession"];
?>
