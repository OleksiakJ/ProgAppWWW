<?php
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
/* po tym komentarzu będzie kod do dynamicznego ładowania stron */ 
if($_GET['idp'] == ''){
    if(file_exists('html/glowna.html'))
        $strona = 'html/glowna.html';
    else{
        $strona = 'html/error.html';
    }
}
if($_GET['idp'] == 'zwyciezcy2023.html'){
    if(file_exists('html/zwyciezcy2023.html'))
        $strona = 'html/zwyciezcy2023.html';
    else{
        $strona = 'html/error.html';
    }
}
if($_GET['idp'] == 'kontakt.html'){
    if(file_exists('html/kontakt.html'))
        $strona = 'html/kontakt.html';
    else{
        $strona = 'html/error.html';
    }
}
if($_GET['idp'] == 'lab2.html'){
    if(file_exists('html/lab2.html'))
        $strona = 'html/lab2.html';
    else{
        $strona = 'html/error.html';
    }
}
if($_GET['idp'] == 'filmy.html'){
    if(file_exists('html/filmy.html'))
        $strona = 'html/filmy.html';
    else{
        $strona = 'html/error.html';
    }
}
?>
<!DOCTYPE html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Language" content="pl" />
    <meta name="Author" content="Jakub Oleksiak" />
    <title>Wszystko o nagrodzie Oscara</title>
    <link rel="stylesheet" href='css/style.css'> 
    <script src="js/kolorujtlo.js" type="text/javascript"></script>
    <script src="js/timedate.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <div id="container">
        <div id="logo">
            <h2>Co to jest nagroda Oscara?</h2>
        </div>
        <div id="nav">
            <a href="?idp=" >Oscar</a>
            <a href="?idp=zwyciezcy2023.html" >Zwyciezcy 2023</a>
            <a href="?idp=kontakt.html" >Kontakt</a>
            <a href="?idp=lab2.html">Laboratorium</a>
            <a href="?idp=filmy.html">Filmy</a>
        </div>
                        <!-- TUTAJ INCLUDE -->
        <?php
            include($strona);
        ?>

<?php
    $nr_indeksu = '164414';
    $nrGrupy = '3';
    echo ('Autor:  Jakub Oleksiak ' .$nr_indeksu .' Grupa: ' .$nrGrupy);
?>
</body>
</html>