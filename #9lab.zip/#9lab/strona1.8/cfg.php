<?php
    //lączenie z bazą danych
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = '';
    $baza = 'moja_strona';

    $link = new mysqli($dbhost, $dbuser, $dbpass, $baza);

    if ($link->connect_error) {
        die("Błąd połączenia z bazą danych: " . $link->connect_error);
    }
    $login = 'admin';
    $pass = 'admin';
?>
